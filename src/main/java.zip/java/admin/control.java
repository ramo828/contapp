/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package admin;

import java.util.Scanner;
import util.utilty;

public class control {

    static Scanner sc = new Scanner(System.in);
    public static int run = 1;
    public static int unrun = 0;

    private static String userName = "admin";
    private static String userPass = "ramiz123";

    public control(int i) {
        if (i != 0) {
            init();
        }
    }

    public control(String login, String pass) {
        while(!(login.length() == 4 && pass.length() == 10)){
        if (userName.equals(login) && userPass.equals(pass)) {
            panel ap = new panel(true);
        } else {
            failAccess();
            init();
        }
        }
        utilty.print("Login ve ya parol heddinden artiq uzundur!");
    }

    public static void setUserName(String userName) {
        control.userName = userName;
    }

    public static void setUserPass(String userPass) {
        control.userPass = userPass;
    }

    private void failAccess() {
        System.out.println("Giris elde olunmadi!\nSifre ve ya login yalnisdir!");
    }

    public static void init() {
        utilty.print("Login: ");
        String login = utilty.scanf(sc);
        utilty.print("Parol: ");
        String pass = utilty.scanf(sc);
        control c = new control(login, pass);
    }

    private String getUserName() {
        return userName;
    }

    private String getUserPass() {
        return userPass;
    }

    public void showAccess(boolean cont) {
        utilty.print("User: " + getUserName() + "\n" + "Password: " + getUserPass());
        if (cont) {
            utilty.quit_or_back(false);
        }

    }

    public void setAccess() {
        utilty.print("New User: ");
        String user = utilty.scanf(sc);
        setUserName(user);
        utilty.print("New Password: ");
        String pass = utilty.scanf(sc);
        setUserPass(pass);
        utilty.print("Yeni Login ve Shifre: ");
        showAccess(false);
        init();
    }
}
