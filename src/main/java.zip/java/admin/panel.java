/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package admin;

import util.utilty;
import java.util.Scanner;

/**
 *
 * @author ramo828
 */
public class panel {

    static control co = new control(0);
    static Scanner sc = new Scanner(System.in);
    static boolean access = false;

    public panel(boolean success) {
        if (success) {
            setAccess(true);
            panelControl();
        } else {

        }
    }

    public panel() {
      //  this(false);
    }

    public static void panelControl(){
        if (access) {
            utilty.print("\t---Sisteme giris elde etdiniz---");
        }
        utilty.print("\n1 - Yeni telebe elave edin\n"
                + "2 - Yeni istifadeki elave edin\n"
                + "3 - Ayarlar\n"
                + "4 - Haqqinda\n"
                + "0 - Cixish\n");
        gotoFunc(utilty.scanfInt(sc));

    }

    private static void gotoFunc(int go) {
        switch (go) {
            case 0:
                utilty.quit_or_back(true);
                break;
            case 1:
                break;
            case 2:
                break;
            case 3:
                settings();
                break;
            case 4:
                utilty.about();
                utilty.dntLabel(true);
                break;
            default:
                utilty.error(0);
                utilty.dntLabel(true);
        }
    }

    private static void gotoFunc2(int go) {
        switch (go) {
            case 0:
                utilty.quit_or_back(false);
                break;
            case 1:
                co.showAccess(true);
                break;
            case 2:
                co.setAccess();
                break;
            case 3:
            default:
                utilty.error(0);
                utilty.dntLabel(false);
        }
    }

    public static void settings() {
        utilty.print("\n1 - parola bax\n"
                + "2 - parolu deyish\n"
                + "0 - Geriye\n");
        gotoFunc2(utilty.scanfInt(sc));

    }

    public static void setAccess(boolean access) {
        panel.access = access;
    }

    
}
